const inputBox = document.getElementById('input-box');
const listArea = document.getElementById('list-sort');
const date = document.getElementById('dateInput');
const dateList = document.getElementById('date-list');
let buttonList = document.getElementsByClassName('inputButton');
let submitButton = document.getElementById('submitDates');
let  dateForm = document.getElementById('form'); 
let addButton = document.getElementById('addButton');
const storedDates = localStorage.getItem('chosenDate');
let listItemDates = document.getElementById('dueDate');
var spanList = document.getElementsByName('spanList');
let dateTag = document.getElementById("dueDate");

function addTask(){
  
    if( inputBox.value == "" ){
        alert("Please make an input!");
    }
    else{
      
       let li = document.createElement('li');
       li.classList.toggle("list-item");
        li.innerHTML = inputBox.value;
        listArea.appendChild(li);
let span = document.createElement("span"); 
span.classList.toggle('spanList');
        li.appendChild(span);
        span.innerHTML = "\u00d7";
let dueDate = document.createElement('p');
dueDate.classList.toggle("dueDate"); 
dueDate.innerHTML = localStorage.getItem('chosenDate');   
li.appendChild(dueDate); 
}        
        inputBox.value = "";
        saveData();
}
if(addButton){
addButton.addEventListener("click", addTask);
}
if(listArea){
listArea.addEventListener("click", function(e) {
 
    if (e.target.tagName === "LI"){
     e.target.classList.toggle("checked");
     saveData(); 
    }
    else if(e.target.tagName === "SPAN"){
        e.target.parentElement.remove();
       var ask = window.confirm('Create another task?');

       if(ask){
        alert('Redirecting to date set up.');
        window.location.href = 'setDate.html';
       }
    for(i = 0; i < storedDates?.length; i++){
        if(i = storedDates.length){
        localStorage.removeItem('chosenDate', i);
        }
        else if(storedDates.length == NULL){
            e.target.parentElement.remove();  
        }
    }         
        }
     saveData(); 
    }, false);
}

function saveData(){
    localStorage.setItem("listItem", listArea.innerHTML);
}
 function showTask(){
if(listArea){
listArea.innerHTML = localStorage.getItem("listItem");
}
 }
 showTask();

 for(i=0;  i < buttonList.length; i++){
    buttonList[i].addEventListener('click', event => {
    localStorage.clear()
    date.value += event.target.value;
    }, false);
    } 


    if(dateForm){
        dateForm.addEventListener('submit', passValue);
        }
        function passValue(event){

            if( dateInput.value == "" ){
                alert("Please make an input!");
                event.preventDefault()
            }
        const chosenDate = date;
        localStorage.setItem('chosenDate', chosenDate);
        window.location.href = "sort.html";

        if(dateInput === ''){
        alert('Invalid Input. Please input a date of your choosing.');
        }
        }



        
        const dueDate = localStorage.getItem('chosenDate');
        
        if(dateTag){
        dateTag.innerHTML = dueDate;
        }
        
  
  
   
    
   
    






